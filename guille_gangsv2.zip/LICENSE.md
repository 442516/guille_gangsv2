License Zero Noncommercial Public License 1.0.0

Copyright: guillerp© 2021

Source: https://github.com/guillerp8/guille_gangsv2

**This software comes as is, without any warranty at all. As far
as the law allows, I will not be liable for any damages related
to this software or this license, for any kind of legal claim.**

As long as you meet the conditions below, you may do everything
with this software that would otherwise infringe my copyright in
it or any covered patent claim. Your permission covers a patent
claim that I can license, or become able to license, if you would
infringe it by using this software as of my latest contribution.

1. You must ensure that everyone who gets a copy of this software
   from you, in source code or any other form, also gets the
   complete text of this license and the copyright and source
   notices above.

2. You must not make any legal claim against anyone for
   infringing any patent claim they would infringe by using this
   software alone, accusing this software, with or without
   changes, alone or combined into a larger program.

3. You must limit use of this software in any manner primarily
   intended for or directed toward commercial advantage, you are 
   not allowed to sell this code.

4. Origen Company is only authorized to use this resource with El Origen RP,
   other servers related with the company cannot use this resource in any term.
   This includes derivations as gang wars servers or related.
