RegisterNetEvent("guille_gangs:client:notify")
AddEventHandler("guille_gangs:client:notify", function(txt)
    notify(txt)
end)